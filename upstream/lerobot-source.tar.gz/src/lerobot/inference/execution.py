# Copyright 2026 The HuggingFace Inc. team. All rights reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Shared chunk scheduling, atomic continuation and local motion permission.

The control thread never waits for an executor. A queue pop commits a policy
endpoint to interpolation; freshness remains attached to that endpoint on every
motor tick, including ticks without a queue pop. All clocks here are client-local.
"""

from __future__ import annotations

import math
import time
from collections import deque
from collections.abc import Callable
from dataclasses import dataclass, replace
from threading import RLock
from uuid import uuid4

import torch

from lerobot.lerobot_types import PolicyPrediction
from lerobot.policies import ActionQueue, QueueSnapshot, RTCConfig

from .contracts import ActionChunk, ActionProvenance, ExecutionMode, ObservationSnapshot
from .latency import LatencyWindow


@dataclass(frozen=True)
class ChunkRequest:
    """Immutable observation/continuation binding for one executor operation."""

    observation: ObservationSnapshot
    continuation: QueueSnapshot
    request_id: str
    generation: int
    mode: ExecutionMode
    delay: int
    submitted_at: float
    playback_at_submission: float = 0.0


@dataclass
class HoldState:
    """Hold acknowledgment and anchored deadline, protected by the engine's lock.

    Engines own motion invalidation, worker ordering and fresh captures. This
    state only coordinates the wait; it never issues hardware commands.
    """

    reason: str | None = None
    started_at: float = 0.0
    deadline: float | None = None
    acknowledged: bool = False

    @property
    def requested(self) -> bool:
        """Whether a hold is awaiting acknowledgment or completion."""
        return self.reason is not None

    @property
    def ready(self) -> bool:
        """Whether the control thread has acknowledged the requested hold."""
        return self.requested and self.acknowledged

    def request(self, reason: str, now: float, timeout_s: float | None, *, upgrade: bool = False) -> bool:
        """Start once; an upgrade keeps the acknowledgment and time anchor and widens the budget once.

        Re-requesting the current reason is a no-op, so per-tick checks never renew a deadline.

        Args:
            reason: Wait identity; changing it permits a one-time upgrade.
            now: Current monotonic time in seconds.
            timeout_s: Budget from the original start, or None for an externally bounded wait.
            upgrade: Allow a different reason to extend the existing budget without restarting it.
        """
        if self.requested:
            if upgrade and reason != self.reason:
                self.reason = reason
                if timeout_s is not None:
                    deadline = self.started_at + timeout_s
                    self.deadline = max(self.deadline, deadline) if self.deadline is not None else deadline
            return False
        self.reason, self.started_at = reason, now
        self.deadline = None if timeout_s is None else now + timeout_s
        self.acknowledged = False
        return True

    def acknowledge(self) -> bool:
        """Return true only on the first acknowledgment of the current hold."""
        if not self.requested or self.acknowledged:
            return False
        self.acknowledged = True
        return True

    def expired(self, now: float) -> bool:
        """Whether the planned wait expired; starvation has its own runtime deadline."""
        return self.deadline is not None and now > self.deadline

    def clear(self) -> None:
        """Clear a completed or superseded wait without changing runtime permission."""
        self.reason = None
        self.started_at = 0.0
        self.deadline = None
        self.acknowledged = False


def estimate_delay(
    turnaround: float, interval: float, mode: ExecutionMode, training_max_delay: int, available: int
) -> int:
    """Estimate overlap in action steps, bounded by real trained-prefix capacity.

    Args:
        turnaround: Full request turnaround in seconds.
        interval: Seconds per policy action.
        mode: Chunk, guided RTC, or trained RTC execution.
        training_max_delay: Maximum prefix steps supported by trained RTC.
        available: Number of unconsumed continuation steps.
    """
    delay = math.ceil(turnaround / interval) if turnaround else 0
    if mode is ExecutionMode.RTC_TRAINED:
        delay = min(delay or training_max_delay, training_max_delay, available)
    return delay if available else 0


def trained_overlap_valid(conditioned: int, measured: int, maximum: int, has_previous: bool) -> bool:
    """Require elapsed overlap to fit both the conditioning and training range."""
    return not has_previous or measured <= min(conditioned, maximum)


class ChunkRuntime:
    """Capacity-one executor scheduling with per-action provenance and latched faults."""

    def __init__(
        self,
        *,
        mode: ExecutionMode,
        action_interval: float,
        refill_seconds: float,
        max_observation_age_s: float,
        action_timeout_s: float,
        startup_timeout_s: float,
        action_starvation_grace_s: float = 0.0,
        training_max_delay: int = 0,
        chunk_merge: str = "append",
        blend_steps: int = 0,
        blend_weight: float = 0.5,
        blend_indices: tuple[int, ...] = (),
        clock: Callable[[], float] = time.monotonic,
    ) -> None:
        """Allocate one action queue and a bounded steady-state latency window."""
        for value in (action_interval, max_observation_age_s, action_timeout_s, startup_timeout_s):
            if not math.isfinite(value) or value <= 0:
                raise ValueError("Execution intervals, ages and deadlines must be finite and positive")
        if not math.isfinite(refill_seconds) or refill_seconds < 0:
            raise ValueError("Refill playback threshold must be finite and nonnegative")
        if not math.isfinite(action_starvation_grace_s) or action_starvation_grace_s < 0:
            raise ValueError("Action starvation grace must be finite and nonnegative")
        if chunk_merge not in {"append", "aligned"} or (
            chunk_merge != "append" and mode is not ExecutionMode.CHUNK
        ):
            raise ValueError("Aligned replacement is supported only for plain chunks")
        if type(blend_steps) is not int or blend_steps < 0:
            raise ValueError("Blend steps must be a nonnegative integer")
        if not math.isfinite(blend_weight) or not 0 < blend_weight <= 1:
            raise ValueError("Incoming blend weight must be in (0, 1]")
        if len(set(blend_indices)) != len(blend_indices) or any(
            type(index) is not int or index < 0 for index in blend_indices
        ):
            raise ValueError("Blend indices must be distinct nonnegative integers")
        if blend_steps and (chunk_merge != "aligned" or not blend_indices):
            raise ValueError("Blending requires alignment and explicit continuous components")
        if blend_indices and not blend_steps:
            raise ValueError("Blend components require a positive blend window")
        self.mode = mode
        self.chunk_merge = chunk_merge
        self.blend_steps = blend_steps
        self.blend_weight = blend_weight
        self.blend_indices = blend_indices
        self.interval = action_interval
        self.refill_seconds = refill_seconds
        self.max_age = max_observation_age_s
        self.action_timeout = action_timeout_s
        self.startup_timeout = startup_timeout_s
        self.starvation_grace = action_starvation_grace_s
        self.starvation_deadline: float | None = None
        self._starvation_request_deadline: float | None = None
        self._starvation_capture_after: float | None = None
        self.training_max_delay = training_max_delay
        self.clock = clock
        self.lock = RLock()
        self.queue = ActionQueue(RTCConfig(enabled=mode is not ExecutionMode.CHUNK))
        self.generation = 0
        self.pending: ChunkRequest | None = None
        self.current: ActionProvenance | None = None
        self.prediction: PolicyPrediction | None = None
        self.failure: str | None = None
        self.active = False
        self.held = False
        self.has_executed = False
        self.started_at = clock()
        self.latency = LatencyWindow("turnaround")
        self.turnarounds: deque[float] = deque(maxlen=100)
        self._initial_turnaround = 0.0
        self._completed = 0
        self._last_anchor: tuple[int, float, int] | None = None
        self.wait_events: deque[dict] = deque(maxlen=128)
        self.last_accept: dict = {}

    @property
    def turnaround(self) -> float:
        """Largest complete action turnaround in the recent steady-state window."""
        return max(self.turnarounds, default=self._initial_turnaround)

    @property
    def effective_refill(self) -> float:
        """Playback threshold including measured turnaround headroom."""
        return max(self.refill_seconds, self.turnaround + self.interval)

    def anchor_observation(self, observation: ObservationSnapshot) -> ObservationSnapshot:
        """Bind a control-thread sample before committing the next endpoint.

        The sampling caller must not pop actions between capture and this call.
        The rollout control thread owns both operations; a worker may replace
        the future concurrently but cannot advance this commitment cursor.
        """
        with self.lock:
            return replace(
                observation,
                action_cursor=self.queue.snapshot().cursor,
                execution_generation=self.generation,
            )

    def invalidate(self, *, held: bool = False, preserve_starvation: bool = False) -> int:
        """Revoke old motion locally and return the new execution generation."""
        with self.lock:
            waiting_deadline = self.starvation_deadline if preserve_starvation else None
            pending_deadline = self._starvation_request_deadline if preserve_starvation else None
            if waiting_deadline is not None and self.pending is not None:
                deadline = self.pending.submitted_at + self.action_timeout
                pending_deadline = (
                    min(pending_deadline, deadline) if pending_deadline is not None else deadline
                )
            self.generation += 1
            self.queue.clear()
            self.pending = None
            self.current = None
            self.prediction = None
            self.held = held
            self.has_executed = False
            self._last_anchor = None
            self.started_at = self.clock()
            self.starvation_deadline = waiting_deadline
            self._starvation_request_deadline = pending_deadline
            self._starvation_capture_after = None
            return self.generation

    def _wait_for_actions(self) -> None:
        """Revoke exhausted motion without forgetting an outstanding call's deadline."""
        if not self.starvation_grace:
            self.fault("Active motion buffer exhausted")
            return
        pending_deadline = (
            self.pending.submitted_at + self.action_timeout if self.pending is not None else None
        )
        self.invalidate(held=True)
        self.starvation_deadline = self.clock() + self.starvation_grace
        self._starvation_request_deadline = pending_deadline
        self.wait_events.append({"event": "waiting", "grace_s": self.starvation_grace})

    def acknowledge_starvation_hold(self) -> None:
        """Require capture after the first successful motor-thread waiting command."""
        with self.lock:
            if self.starvation_deadline is not None and self._starvation_capture_after is None:
                self._starvation_capture_after = self.clock()

    def complete_starvation_invalidation(self, generation: int) -> None:
        """Retire the old call deadline only after serialized worker invalidation."""
        with self.lock:
            self.check_deadlines()
            if not self.failure and generation == self.generation:
                self._starvation_request_deadline = None

    def activate(self, *, held: bool = False) -> bool:
        """Activate a healthy run and atomically arm its startup budget."""
        with self.lock:
            if self.failure is not None:
                return False
            self.active = True
            self.held = held
            self.started_at = self.clock()
            return True

    def deactivate(self) -> None:
        """Revoke motion and pending work atomically without clearing a fault."""
        with self.lock:
            self.active = False
            self.invalidate(held=True)

    def release_hold(self, expected_generation: int) -> bool:
        """Arm fresh resumption only for the same healthy, active generation."""
        with self.lock:
            self.check_deadlines()
            if self.failure is not None or not self.active or self.generation != expected_generation:
                return False
            self.started_at = self.clock()
            self.held = False
            return True

    def drain_wait_events(self) -> list[dict]:
        """Atomically take waiting/recovery notices for backend logging."""
        with self.lock:
            events = list(self.wait_events)
            self.wait_events.clear()
            return events

    def fault(self, reason: str) -> None:
        """Latch a terminal fault; invalidate does not clear this latch."""
        with self.lock:
            if self.failure is None:
                self.failure = reason
                self.invalidate(held=True)
                self.active = False

    def check_deadlines(self) -> None:
        """Enforce local action/startup bounds even while network work is blocked."""
        with self.lock:
            if self.failure or not self.active:
                return
            now = self.clock()
            if self.starvation_deadline is not None:
                if self._starvation_request_deadline is not None and now > self._starvation_request_deadline:
                    self.fault("Action request deadline exceeded while waiting for fresh actions")
                    return
                if now > self.starvation_deadline:
                    self.fault("Active motion buffer exhausted: action starvation grace expired")
                    return
            if self.held:
                return
            if self.pending is not None and now - self.pending.submitted_at > self.action_timeout:
                self.fault("Action request deadline exceeded")
            elif not self.has_executed and now - self.started_at > self.startup_timeout:
                self.fault("Initial action deadline exceeded")

    def should_request(self, *, task_version: int | None = None) -> bool:
        """Check permission and playback need without reserving an observation.

        Aligned task changes may bypass the playback threshold. ``begin`` still
        validates their fresh capture, generation and commitment anchor.
        """
        with self.lock:
            self.check_deadlines()
            if self.failure or not self.active or self.held or self.pending is not None:
                return False
            snapshot = self.queue.snapshot()
            if (
                self.chunk_merge == "aligned"
                and task_version is not None
                and self._last_anchor is not None
                and task_version != self._last_anchor[2]
            ):
                return True
            if self.mode is ExecutionMode.CHUNK and self.chunk_merge == "append":
                # One accepted successor beyond the executing chunk, never a chain
                # of old-observation predictions hidden behind newer provenance.
                sources = {p.request_id for p in snapshot.provenance if p is not None}
                if len(sources) > 1:
                    return False
                if self.current and sources and self.current.request_id not in sources:
                    return False
            playback = self.queue.qsize() * self.interval
            return playback <= self.effective_refill + 1e-9

    def begin(self, observation: ObservationSnapshot) -> ChunkRequest | None:
        """Reserve inference against one atomic cursor/continuation snapshot."""
        with self.lock:
            if not self.should_request(task_version=observation.task_version):
                return None
            age = self.clock() - observation.capture_time
            if age < 0 or age > self.max_age:
                return None  # wait for a fresh capture; startup/dispatch deadlines still apply
            if self.starvation_deadline is not None and (
                self._starvation_capture_after is None
                or observation.capture_time < self._starvation_capture_after
            ):
                return None
            snapshot = self.queue.snapshot()
            if self.chunk_merge == "aligned":
                if (
                    observation.execution_generation != self.generation
                    or observation.action_cursor is None
                    or observation.action_cursor > snapshot.cursor
                    or observation.capture_time < self.started_at
                ):
                    return None
                if self._last_anchor is not None and (
                    (
                        observation.task_version == self._last_anchor[2]
                        and observation.action_cursor <= self._last_anchor[0]
                    )
                    or observation.capture_time <= self._last_anchor[1]
                ):
                    return None
                self._last_anchor = (
                    observation.action_cursor,
                    observation.capture_time,
                    observation.task_version,
                )
            available = 0 if snapshot.model_actions is None else len(snapshot.model_actions)
            self.pending = ChunkRequest(
                observation,
                snapshot,
                uuid4().hex,
                self.generation,
                self.mode,
                estimate_delay(self.turnaround, self.interval, self.mode, self.training_max_delay, available),
                self.clock(),
                len(snapshot.provenance) * self.interval,
            )
            return self.pending

    def accept(self, request: ChunkRequest, chunk: ActionChunk, *, task_version: int) -> bool:
        """Validate context and timing, then atomically merge with original provenance."""
        with self.lock:
            self.last_accept = {"accepted": False}
            self.check_deadlines()
            if self.failure or self.pending is not request or request.generation != self.generation:
                return False
            self.pending = None
            if request.observation.task_version != task_version:
                return False
            now = self.clock()
            elapsed = now - request.submitted_at
            self.latency.record(elapsed, now)
            self._completed += 1
            if self._completed > 1:  # cold start is not a steady-state action latency
                self.turnarounds.append(elapsed)
            else:
                # Until a warm measurement exists, reserving less than the only
                # observed turnaround can deterministically starve request two.
                self._initial_turnaround = elapsed
            if now - request.observation.capture_time > self.max_age:
                self.fault("Action result source observation is too old")
                return False
            actions = chunk.canonical_actions
            model = chunk.model_actions if chunk.model_actions is not None else actions
            if (
                actions.ndim != 2
                or model.ndim != 2
                or len(actions) != len(model)
                or not len(actions)
                or type(chunk.execution_steps) is not int
                or not 0 < chunk.execution_steps <= len(actions)
                or not torch.isfinite(actions).all()
                or not torch.isfinite(model).all()
            ):
                self.fault("Invalid action chunk")
                return False
            # The runner/client already enforces the slice. Keep the shared
            # executor strict even for independently supplied ActionChunks.
            if self.mode is ExecutionMode.CHUNK:
                actions = actions[: chunk.execution_steps]
                model = model[: chunk.execution_steps]
            progress = self.queue.snapshot().cursor - request.continuation.cursor
            measured = math.ceil(elapsed / self.interval)
            available = request.continuation.model_actions
            has_previous = available is not None and len(available) > 0
            if self.mode is ExecutionMode.RTC_TRAINED and not trained_overlap_valid(
                request.delay, max(measured, progress), self.training_max_delay, has_previous
            ):
                return False
            trim = min(measured, progress) if self.mode is not ExecutionMode.CHUNK else 0
            if trim >= len(actions):
                self.fault("Inference completed beyond its usable continuation horizon")
                return False
            provenance = replace(
                chunk.provenance,
                request_id=request.request_id,
                generation=request.generation,
                capture_time=request.observation.capture_time,
                task=request.observation.task,
                task_version=request.observation.task_version,
                observation_id=request.observation.observation_id,
            )
            self.last_accept.update(
                trimmed_actions=trim,
                overlap_steps=0,
                blended_steps=0,
            )
            if self.chunk_merge == "aligned":
                accepted = self._accept_aligned(request, actions, provenance, now)
            else:
                accepted = self.queue.merge(
                    model,
                    actions,
                    measured,
                    task=provenance.task,
                    provenance=provenance,
                    snapshot=request.continuation,
                )
            self.last_accept["accepted"] = accepted
            if accepted and chunk.prediction is not None:
                self.prediction = chunk.prediction
            if accepted and self.starvation_deadline is not None:
                self.wait_events.append(
                    {"event": "resumed", "wait_s": now - (self.starvation_deadline - self.starvation_grace)}
                )
                self.starvation_deadline = None
                self._starvation_capture_after = None
                self._starvation_request_deadline = None
            return accepted

    @staticmethod
    def _same_context(old: ActionProvenance, new: ActionProvenance) -> bool:
        return all(
            getattr(old, key) == getattr(new, key)
            for key in (
                "task",
                "task_version",
                "generation",
                "session_id",
                "server_instance_id",
                "artifact_identity",
            )
        )

    def _accept_aligned(
        self, request: ChunkRequest, actions: torch.Tensor, provenance: ActionProvenance, now: float
    ) -> bool:
        snapshot = self.queue.snapshot()
        anchor = request.observation.action_cursor
        if anchor is None or request.observation.execution_generation != self.generation:
            self.fault("Aligned result lacks its observation commitment anchor")
            return False
        trim = snapshot.cursor - anchor
        self.last_accept["trimmed_actions"] = trim
        if trim < 0 or trim >= len(actions):
            self.last_accept["rejection"] = "no usable aligned suffix"
            return False
        future = actions[trim:].clone()
        sources = [provenance] * len(future)
        previous = snapshot.canonical_actions
        overlap = min(len(previous), len(future)) if previous is not None else 0
        self.last_accept["overlap_steps"] = overlap
        if self.blend_indices and max(self.blend_indices) >= future.shape[1]:
            self.fault("Blend component index exceeds canonical action dimensions")
            return False
        if previous is not None and self.blend_weight < 1:
            for index in range(min(overlap, self.blend_steps)):
                old = snapshot.provenance[index]
                if (
                    old is None
                    or not self._same_context(old, provenance)
                    or not 0 <= now - old.capture_time <= self.max_age
                ):
                    continue
                coordinates = list(self.blend_indices)
                future[index, coordinates] = (1 - self.blend_weight) * previous[
                    index, coordinates
                ] + self.blend_weight * future[index, coordinates]
                sources[index] = replace(
                    provenance, capture_time=min(old.capture_time, provenance.capture_time)
                )
                self.last_accept["blended_steps"] += 1
        accepted = self.queue.replace_future(future, sources, snapshot=snapshot)
        self.last_accept.update(
            accepted=accepted,
            usable_actions=len(future),
        )
        return accepted

    def take_prediction(self) -> PolicyPrediction | None:
        """Hand out the latest accepted chunk's prediction once."""
        with self.lock:
            prediction, self.prediction = self.prediction, None
            return prediction

    def dispatch_allowed(self) -> bool:
        """Check permission and the committed endpoint's age on every motor tick."""
        with self.lock:
            self.check_deadlines()
            if self.failure or not self.active or self.held:
                return False
            if self.current is not None and self.clock() - self.current.capture_time > self.max_age:
                self.fault("Dispatched action source observation is too old")
                return False
            return self.current is not None or not self.queue.empty()

    def pop(self) -> tuple[torch.Tensor, ActionProvenance] | None:
        """Commit an endpoint to interpolation; its provenance remains age-checked."""
        with self.lock:
            if not self.dispatch_allowed():
                return None
            item = self.queue.get_with_provenance()
            if item is None:
                if self.has_executed:
                    self._wait_for_actions()
                return None
            action, _, provenance = item
            if provenance is None:
                self.fault("Action lacks request provenance")
                return None
            self.current = provenance
            self.has_executed = True
            if not self.dispatch_allowed():
                return None
            return action, provenance
