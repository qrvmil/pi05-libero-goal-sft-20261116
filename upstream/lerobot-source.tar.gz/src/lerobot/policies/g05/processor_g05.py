# SPDX-License-Identifier: LicenseRef-G0.5-Community-1.0
# Copyright (c) 2026 Galaxea
# Modified for LeRobot in 2026.

"""G0.5 pre/post-processing steps and the pipeline factory (the tokenizer lives in `tokenizer_g05.py`)."""

from __future__ import annotations

import json
import shutil
from collections.abc import Mapping
from dataclasses import dataclass, field
from pathlib import Path
from types import SimpleNamespace
from typing import TYPE_CHECKING, Any

import torch
import torchvision.transforms.functional as vision_functional
from huggingface_hub import snapshot_download
from torch import Tensor

from lerobot.configs.types import FeatureType, NormalizationMode, PipelineFeatureType, PolicyFeature
from lerobot.lerobot_types import EnvTransition, RobotObservation, TransitionKey
from lerobot.processor import (
    AbsoluteActionsProcessorStep,
    AddBatchDimensionProcessorStep,
    DeviceProcessorStep,
    NormalizerProcessorStep,
    ObservationProcessorStep,
    PolicyAction,
    PolicyActionProcessorStep,
    PolicyProcessorPipeline,
    ProcessorStep,
    ProcessorStepRegistry,
    RelativeActionsProcessorStep,
    RenameObservationsProcessorStep,
    RenderRuntimeMessagesStep,
    RenderTrainingMessagesStep,
    UnnormalizerProcessorStep,
    load_pretrained_policy_processors,
)
from lerobot.processor.converters import (
    batch_to_transition,
    policy_action_to_transition,
    transition_to_batch,
    transition_to_policy_action,
)
from lerobot.processor.relative_action_processor import to_relative_actions
from lerobot.utils.constants import (
    ACTION,
    MESSAGES_RENDERED,
    OBS_STATE,
    POLICY_POSTPROCESSOR_DEFAULT_NAME,
    POLICY_PREPROCESSOR_DEFAULT_NAME,
)
from lerobot.utils.language import (
    last_semantic_message_text,
    require_single_semantic_conversation,
    semantic_message_content_text,
)

from .action_codec_g05 import G05NativeActionCodec
from .configuration_g05 import (
    G05_COT_PROMPTS,
    G05_EMBODIMENT_MAPPINGS,
    G05Config,
    make_g05_cot_prompt_template,
    make_g05_prompt_template,
)
from .tokenizer_g05 import (
    G05_INPUT_IDS,
    G05_LABELS,
    G05_RUNTIME_PREDICT_COT,
    G05_SPLIT_INDEX,
    G05_TOKEN_TYPES,
    G05Tokenizer,
)

if TYPE_CHECKING:
    from lerobot.datasets.recipe import TrainingRecipe


def _copy_feature_tree(
    features: dict[PipelineFeatureType, dict[str, PolicyFeature]],
) -> dict[PipelineFeatureType, dict[str, PolicyFeature]]:
    """Shallow-copy a feature tree so a step can edit its own view of the features."""
    return {kind: values.copy() for kind, values in features.items()}


@dataclass
class _G05JointFrameMixin:
    """Per-joint affine between the physical-arm frame and the checkpoint frame.

    ``value -> sign * value + offset``; the inverse is ``(value - offset) / sign``.
    """

    joint_signs: tuple[float, ...] = ()
    joint_offsets: tuple[float, ...] = ()

    def __post_init__(self) -> None:
        # Pipelines restored from JSON hand these back as lists.
        """Coerce the sign and offset tables and check they stay invertible."""
        self.joint_signs = tuple(float(value) for value in self.joint_signs)
        self.joint_offsets = tuple(float(value) for value in self.joint_offsets)
        if len(self.joint_signs) != len(self.joint_offsets):
            raise ValueError("joint_signs and joint_offsets must have the same length.")
        if any(sign == 0.0 for sign in self.joint_signs):
            raise ValueError("joint_signs entries must be non-zero so the transform is invertible.")

    def _reframe(self, values: torch.Tensor, *, inverse: bool) -> torch.Tensor:
        """Apply `sign * value + offset` over the leading joints, or its inverse."""
        width = len(self.joint_signs)
        if values.shape[-1] < width:
            raise ValueError(f"G0.5 joint frame covers {width} joints but the tensor has {values.shape[-1]}.")
        result = values if torch.is_floating_point(values) else values.float()
        result = result.clone()
        signs = result.new_tensor(self.joint_signs)
        offsets = result.new_tensor(self.joint_offsets)
        if inverse:
            result[..., :width] = (result[..., :width] - offsets) / signs
        else:
            result[..., :width] = signs * result[..., :width] + offsets
        return result

    def transform_features(
        self, features: dict[PipelineFeatureType, dict[str, PolicyFeature]]
    ) -> dict[PipelineFeatureType, dict[str, PolicyFeature]]:
        """Pass the feature contract through unchanged."""
        return features

    def get_config(self) -> dict[str, Any]:
        """Return this step's serializable configuration."""
        return {
            "joint_signs": list(self.joint_signs),
            "joint_offsets": list(self.joint_offsets),
        }


@dataclass
@ProcessorStepRegistry.register(name="g05_state_frame_transform")
class G05StateFrameTransformStep(_G05JointFrameMixin, ObservationProcessorStep):
    """Move proprioception into the coordinate frame the checkpoint was trained in."""

    def observation(self, observation: dict[str, Any]) -> dict[str, Any]:
        """Reframe `observation.state` into the checkpoint's joint convention."""
        if not self.joint_signs or OBS_STATE not in observation:
            return observation
        state = torch.as_tensor(observation[OBS_STATE])
        observation[OBS_STATE] = self._reframe(state, inverse=False)
        return observation


@dataclass
@ProcessorStepRegistry.register(name="g05_action_frame_transform")
class G05ActionFrameTransformStep(_G05JointFrameMixin, ProcessorStep):
    """Move actions between the physical-arm frame and the checkpoint frame.

    ``inverse=True`` undoes :class:`G05StateFrameTransformStep` on a predicted
    action; ``inverse=False`` applies the same forward transform to a dataset
    action before the relative-action step differences it.

    Subclasses ``ProcessorStep`` rather than ``ActionProcessorStep``: that base
    rejects a transition without an action, but the forward instance sits in the
    preprocessor, where inference transitions legitimately carry none.
    """

    inverse: bool = True

    def __call__(self, transition: EnvTransition) -> EnvTransition:
        """Reframe the action between the arm and checkpoint joint conventions."""
        action = transition.get(TransitionKey.ACTION)
        if not self.joint_signs or not isinstance(action, torch.Tensor):
            return transition
        transition = transition.copy()
        transition[TransitionKey.ACTION] = self._reframe(action, inverse=self.inverse)
        return transition

    def get_config(self) -> dict[str, Any]:
        """Return this step's serializable configuration."""
        return {**super().get_config(), "inverse": self.inverse}


@dataclass
@ProcessorStepRegistry.register(name="g05_image_transform")
class G05ImageTransformStep(ObservationProcessorStep):
    """Apply the checkpoint's per-camera resize and ``[0,1]`` to ``[-1,1]`` transform."""

    camera_order: tuple[str, ...]
    camera_sizes: dict[str, tuple[int, int]]
    mean: tuple[float, float, float]
    std: tuple[float, float, float]
    optional_camera_keys: tuple[str, ...] = ()

    def __post_init__(self) -> None:
        """Freeze the camera tables into tuples."""
        self.camera_order = tuple(self.camera_order)
        self.camera_sizes = {key: (int(value[0]), int(value[1])) for key, value in self.camera_sizes.items()}
        self.mean = (float(self.mean[0]), float(self.mean[1]), float(self.mean[2]))
        self.std = (float(self.std[0]), float(self.std[1]), float(self.std[2]))
        self.optional_camera_keys = tuple(self.optional_camera_keys)

    def observation(self, observation: RobotObservation) -> RobotObservation:
        """Resize each camera to its checkpoint size and rescale `[0,1]` to `[-1,1]`."""
        missing = [key for key in self.camera_order if key not in observation]
        required_missing = [key for key in missing if key not in self.optional_camera_keys]
        if required_missing:
            raise ValueError(f"G0.5 is missing camera(s) {missing}; required order is {self.camera_order}.")
        if missing:
            reference = next(
                (torch.as_tensor(observation[key]) for key in self.camera_order if key in observation),
                None,
            )
            if reference is None:
                raise ValueError("G0.5 cannot pad optional cameras without one available reference camera.")
            for key in missing:
                height, width = self.camera_sizes[key]
                observation[key] = reference.new_zeros(*reference.shape[:-2], height, width)
        for key in self.camera_order:
            image = torch.as_tensor(observation[key])
            if image.ndim < 3 or image.shape[-3] != 3:
                raise ValueError(f"G0.5 camera {key!r} must end in [3,H,W], got {image.shape}.")
            was_floating_point = torch.is_floating_point(image)
            flat = image.reshape(-1, *image.shape[-3:])
            target_size = self.camera_sizes[key]
            if tuple(flat.shape[-2:]) != target_size:
                # The author prepends torchvision Resize before its uint8-to-float
                # transform. Preserve its antialiasing and uint8 quantization.
                flat = vision_functional.resize(flat, list(target_size))
            flat = flat.float()
            if not was_floating_point:
                flat = flat / 255.0
            mean = flat.new_tensor(self.mean).view(1, 3, 1, 1)
            std = flat.new_tensor(self.std).view(1, 3, 1, 1)
            observation[key] = ((flat - mean) / std).reshape(*image.shape[:-3], 3, *target_size)
        return observation

    def transform_features(
        self, features: dict[PipelineFeatureType, dict[str, PolicyFeature]]
    ) -> dict[PipelineFeatureType, dict[str, PolicyFeature]]:
        """Resize the declared camera features to their checkpoint sizes."""
        result = _copy_feature_tree(features)
        observations = result.setdefault(PipelineFeatureType.OBSERVATION, {})
        for key in self.camera_order:
            height, width = self.camera_sizes[key]
            observations[key] = PolicyFeature(type=FeatureType.VISUAL, shape=(3, height, width))
        return result

    def get_config(self) -> dict[str, Any]:
        """Return this step's serializable configuration."""
        return {
            "camera_order": list(self.camera_order),
            "camera_sizes": {key: list(value) for key, value in self.camera_sizes.items()},
            "mean": list(self.mean),
            "std": list(self.std),
            "optional_camera_keys": list(self.optional_camera_keys),
        }


@dataclass
@ProcessorStepRegistry.register(name="g05_action_operation_mask")
class G05ActionOperationMaskStep(ProcessorStep):
    """Reproduce the author's per-part R1 movement mask used by ActionCodec."""

    action_parts: tuple[tuple[str, int], ...]
    joint_threshold: float | None = None
    gripper_threshold: float | None = None
    velocity_threshold: float | None = None
    eef_threshold: float | None = 1e-3
    dim_thresholds: dict[str, tuple[float, ...]] = field(default_factory=dict)

    _VELOCITY_KEYS = ("torso", "chassis")

    def __post_init__(self) -> None:
        """Coerce the action part widths and per-dimension thresholds."""
        self.action_parts = tuple((key, int(width)) for key, width in self.action_parts)
        self.dim_thresholds = {
            key: tuple(float(value) for value in values) for key, values in self.dim_thresholds.items()
        }

    def _threshold(self, key: str, width: int, action: torch.Tensor) -> torch.Tensor:
        """Resolve the per-dimension motion threshold for one named action part."""
        if key in self.dim_thresholds:
            values = self.dim_thresholds[key]
            if len(values) != width:
                raise ValueError(
                    f"G0.5 action filter threshold {key!r} has {len(values)} values, expected {width}."
                )
            return action.new_tensor(values)
        if "gripper" in key:
            value = self.gripper_threshold
        elif "eef" in key or "ee_pose" in key:
            value = self.eef_threshold
        elif any(velocity_key in key for velocity_key in self._VELOCITY_KEYS):
            value = self.velocity_threshold
        else:
            value = self.joint_threshold
        return action.new_full((width,), float(value or 0.0))

    def __call__(self, transition: EnvTransition) -> EnvTransition:
        """Flag action parts whose motion over the chunk stays under their threshold."""
        action = transition.get(TransitionKey.ACTION)
        if not isinstance(action, torch.Tensor):
            return transition
        if action.shape[-1] != sum(width for _, width in self.action_parts):
            raise ValueError("G0.5 action filter metadata does not match the raw action width.")
        half = action.shape[-2] // 2
        masks = []
        offset = 0
        for key, width in self.action_parts:
            part = action[..., offset : offset + width]
            threshold = self._threshold(key, width, action)
            if "hand" in key:
                flag = torch.ones(*part.shape[:-2], width, dtype=torch.bool, device=part.device)
            elif any(velocity_key in key for velocity_key in self._VELOCITY_KEYS):
                flag = (part[..., :half, :].abs() >= threshold).any(dim=-2)
            else:
                deviation = (part[..., :half, :] - part[..., :1, :]).abs()
                flag = (deviation >= threshold).any(dim=-2)
            masks.append(flag)
            offset += width
        transition = transition.copy()
        complementary = dict(transition.get(TransitionKey.COMPLEMENTARY_DATA) or {})
        complementary["action_op_mask"] = torch.cat(masks, dim=-1)
        transition[TransitionKey.COMPLEMENTARY_DATA] = complementary
        return transition

    def transform_features(
        self, features: dict[PipelineFeatureType, dict[str, PolicyFeature]]
    ) -> dict[PipelineFeatureType, dict[str, PolicyFeature]]:
        """Pass the feature contract through unchanged."""
        return features

    def get_config(self) -> dict[str, Any]:
        """Return this step's serializable configuration."""
        return {
            "action_parts": [list(part) for part in self.action_parts],
            "joint_threshold": self.joint_threshold,
            "gripper_threshold": self.gripper_threshold,
            "velocity_threshold": self.velocity_threshold,
            "eef_threshold": self.eef_threshold,
            "dim_thresholds": {key: list(values) for key, values in self.dim_thresholds.items()},
        }


@dataclass
@ProcessorStepRegistry.register(name="g05_embodiment_projection")
class G05EmbodimentProjectionStep(ProcessorStep):
    """Map raw embodiment coordinates into the checkpoint's padded policy layout."""

    embodiment: str
    policy_state_dim: int
    policy_action_dim: int
    camera_order: tuple[str, ...]
    # Empty on pipelines saved before slots were serialized: the embodiment's table then applies.
    state_slots: tuple[int, ...] = ()
    action_slots: tuple[int, ...] = ()

    def __post_init__(self) -> None:
        """Freeze the camera order and resolve the slots."""
        self.camera_order = tuple(self.camera_order)
        if not self.state_slots:
            if self.embodiment not in G05_EMBODIMENT_MAPPINGS:
                raise ValueError(f"No projection is defined for G0.5 embodiment {self.embodiment!r}.")
            self.state_slots = G05_EMBODIMENT_MAPPINGS[self.embodiment]["state"]
            self.action_slots = G05_EMBODIMENT_MAPPINGS[self.embodiment]["action"]
        self.state_slots = tuple(self.state_slots)
        self.action_slots = tuple(self.action_slots)

    @property
    def mapping(self) -> dict[str, tuple[int, ...]]:
        """Policy-slot indices the raw state and action are written into."""
        return {"state": self.state_slots, "action": self.action_slots}

    @staticmethod
    def _project(value: torch.Tensor, indices: tuple[int, ...], width: int) -> torch.Tensor:
        """Scatter a raw tensor into a zero-filled tensor of the policy's width."""
        if value.shape[-1] != len(indices):
            raise ValueError(f"Raw G0.5 tensor has {value.shape[-1]} dimensions, expected {len(indices)}.")
        projected = value.new_zeros(*value.shape[:-1], width)
        projected[..., list(indices)] = value
        return projected

    def __call__(self, transition: EnvTransition) -> EnvTransition:
        """Project raw state and action into the policy layout and order the cameras."""
        transition = transition.copy()
        observation = dict(transition.get(TransitionKey.OBSERVATION) or {})
        missing_cameras = [key for key in self.camera_order if key not in observation]
        if missing_cameras and any(key.startswith("observation.images.") for key in observation):
            raise ValueError(
                f"G0.5 {self.embodiment} is missing camera(s) {missing_cameras}; "
                f"required order is {self.camera_order}."
            )
        if OBS_STATE in observation:
            raw_state = observation[OBS_STATE]
            if self.embodiment == "libero" and raw_state.shape[-1] == 8:
                # LeRobot's generic LIBERO env exposes both parallel-jaw qpos
                # values. The author evaluator consumes only qpos[0].
                raw_state = raw_state[..., :7]
            observation[OBS_STATE] = self._project(raw_state, self.mapping["state"], self.policy_state_dim)
            # Masks describe feature dimensions, not observation-history timesteps.
            batch_shape = raw_state.shape[:-2] if raw_state.ndim >= 3 else raw_state.shape[:-1]
            complementary = dict(transition.get(TransitionKey.COMPLEMENTARY_DATA) or {})
            action_mask = torch.ones(
                *batch_shape,
                self.policy_action_dim,
                dtype=torch.bool,
                device=observation[OBS_STATE].device,
            )
            action_mask[..., list(self.mapping["action"])] = False
            complementary["action_dim_is_pad"] = action_mask
            raw_action_op_mask = complementary.get("action_op_mask")
            if isinstance(raw_action_op_mask, torch.Tensor):
                complementary["action_op_mask"] = self._project(
                    raw_action_op_mask, self.mapping["action"], self.policy_action_dim
                ).bool()
            else:
                complementary["action_op_mask"] = ~action_mask
            complementary["g05_camera_order"] = self.camera_order
            transition[TransitionKey.COMPLEMENTARY_DATA] = complementary
        action = transition.get(TransitionKey.ACTION)
        if isinstance(action, torch.Tensor):
            transition[TransitionKey.ACTION] = self._project(
                action, self.mapping["action"], self.policy_action_dim
            )
            batch_shape = action.shape[:1] if action.ndim >= 3 else ()
            action_mask = torch.ones(
                *batch_shape, self.policy_action_dim, dtype=torch.bool, device=action.device
            )
            action_mask[..., list(self.mapping["action"])] = False
            complementary = dict(transition.get(TransitionKey.COMPLEMENTARY_DATA) or {})
            complementary.setdefault("action_dim_is_pad", action_mask)
            if "action_is_pad" not in complementary:
                complementary["action_is_pad"] = torch.zeros(
                    *action.shape[:-1], dtype=torch.bool, device=action.device
                )
            transition[TransitionKey.COMPLEMENTARY_DATA] = complementary
        transition[TransitionKey.OBSERVATION] = observation
        return transition

    def transform_features(
        self, features: dict[PipelineFeatureType, dict[str, PolicyFeature]]
    ) -> dict[PipelineFeatureType, dict[str, PolicyFeature]]:
        """Widen the state and action features to the policy dimensions."""
        result = _copy_feature_tree(features)
        observations = result.setdefault(PipelineFeatureType.OBSERVATION, {})
        if OBS_STATE in observations:
            observations[OBS_STATE] = PolicyFeature(type=FeatureType.STATE, shape=(self.policy_state_dim,))
        actions = result.setdefault(PipelineFeatureType.ACTION, {})
        if ACTION in actions:
            actions[ACTION] = PolicyFeature(type=FeatureType.ACTION, shape=(self.policy_action_dim,))
        return result

    def get_config(self) -> dict[str, Any]:
        """Return this step's serializable configuration."""
        return {
            "embodiment": self.embodiment,
            "policy_state_dim": self.policy_state_dim,
            "policy_action_dim": self.policy_action_dim,
            "camera_order": list(self.camera_order),
            "state_slots": list(self.state_slots),
            "action_slots": list(self.action_slots),
        }


@dataclass
@ProcessorStepRegistry.register(name="g05_relative_joint_actions")
class G05RelativeJointActionsStep(RelativeActionsProcessorStep):
    """Author-compatible joint deltas using the last proprio history step."""

    num_obs_steps: int = 1

    def __call__(self, transition: EnvTransition) -> EnvTransition:
        """Cache the latest proprio step, and convert the action to deltas when enabled."""
        observation = transition.get(TransitionKey.OBSERVATION, {})
        state = observation.get(OBS_STATE) if observation else None
        if isinstance(state, torch.Tensor) and state.ndim >= 3:
            state = state[..., -1, :]
        elif (
            isinstance(state, torch.Tensor)
            and state.ndim == 2
            and self.num_obs_steps > 1
            and state.shape[-2] == self.num_obs_steps
        ):
            state = state[-1]
        # Hold the anchor for as long as the policy is still serving the chunk that was
        # generated against it; a fresh chunk re-anchors when the queue drains. Mirrors
        # `RelativeActionsProcessorStep`: re-anchoring every tick makes each action in a
        # chunk relative to the position the previous one already reached, so commands
        # accumulate across the chunk and jump at the seam.
        if state is not None and not self._chunk_in_flight():
            self._last_state = state
        if not self.enabled:
            return transition
        new_transition = transition.copy()
        action = new_transition.get(TransitionKey.ACTION)
        if isinstance(action, torch.Tensor) and state is not None:
            mask = self._build_mask(action.shape[-1])
            new_transition[TransitionKey.ACTION] = to_relative_actions(action, state, mask)
        return new_transition

    def get_config(self) -> dict[str, Any]:
        """Return this step's serializable configuration."""
        return {**super().get_config(), "num_obs_steps": self.num_obs_steps}


@dataclass
@ProcessorStepRegistry.register(name="g05_normalization_clamp")
class G05NormalizationClampStep(ProcessorStep):
    """Match the author's finite clamp after normalization."""

    minimum: float = -5.0
    maximum: float = 5.0

    def _clamp(self, value: torch.Tensor) -> torch.Tensor:
        """Clamp to the configured range and replace any non-finite value with zero."""
        return value.clamp(self.minimum, self.maximum).nan_to_num(nan=0.0, posinf=0.0, neginf=0.0)

    def __call__(self, transition: EnvTransition) -> EnvTransition:
        """Clamp normalized `observation.state` and action to the checkpoint's range."""
        transition = transition.copy()
        observation = dict(transition.get(TransitionKey.OBSERVATION) or {})
        if OBS_STATE in observation:
            observation[OBS_STATE] = self._clamp(observation[OBS_STATE])
        transition[TransitionKey.OBSERVATION] = observation
        action = transition.get(TransitionKey.ACTION)
        if isinstance(action, torch.Tensor):
            transition[TransitionKey.ACTION] = self._clamp(action)
        return transition

    def transform_features(
        self, features: dict[PipelineFeatureType, dict[str, PolicyFeature]]
    ) -> dict[PipelineFeatureType, dict[str, PolicyFeature]]:
        """Pass the feature contract through unchanged."""
        return features

    def get_config(self) -> dict[str, Any]:
        """Return this step's serializable configuration."""
        return {"minimum": self.minimum, "maximum": self.maximum}


@dataclass
@ProcessorStepRegistry.register(name="g05_stepwise_unnormalizer")
class G05StepwiseUnnormalizerStep(UnnormalizerProcessorStep):
    """Apply the checkpoint's action-timestep statistics to queued single actions."""

    n_action_steps: int = 1
    _action_index: int = field(default=0, init=False, repr=False)

    def __call__(self, transition: EnvTransition) -> EnvTransition:
        """Unnormalize a queued single action with that timestep's slice of the stats."""
        action = transition.get(TransitionKey.ACTION)
        stats = self._tensor_stats.get(ACTION)
        if not isinstance(action, torch.Tensor) or not stats:
            return super().__call__(transition)

        first_stat = next(iter(stats.values()))
        if first_stat.device != action.device or first_stat.dtype != action.dtype:
            self.to(device=action.device, dtype=action.dtype)
            stats = self._tensor_stats[ACTION]
            first_stat = next(iter(stats.values()))

        stats_steps = first_stat.shape[-2] if first_stat.ndim >= 2 else 1
        is_single_queued_action = action.ndim <= 2 and action.shape[-2] != stats_steps
        if not is_single_queued_action or stats_steps == 1:
            return super().__call__(transition)

        index = self._action_index % min(self.n_action_steps, stats_steps)
        self._tensor_stats[ACTION] = {
            name: value[index] if value.ndim >= 2 and value.shape[-2] == stats_steps else value
            for name, value in stats.items()
        }
        try:
            return super().__call__(transition)
        finally:
            self._tensor_stats[ACTION] = stats
            self._action_index = (self._action_index + 1) % self.n_action_steps

    def reset(self) -> None:
        """Rewind to the first action of the chunk."""
        self._action_index = 0

    def get_config(self) -> dict[str, Any]:
        """Return this step's serializable configuration."""
        return {**super().get_config(), "n_action_steps": self.n_action_steps}


@dataclass
@ProcessorStepRegistry.register(name="g05_inverse_action_projection")
class G05InverseActionProjectionStep(PolicyActionProcessorStep):
    """Project policy-layout actions back to the environment's exact raw layout."""

    embodiment: str
    policy_action_dim: int
    # Empty on pipelines saved before slots were serialized: the embodiment's table then applies.
    action_slots: tuple[int, ...] = ()

    def __post_init__(self) -> None:
        """Resolve the action slots."""
        self.action_slots = tuple(self.action_slots or G05_EMBODIMENT_MAPPINGS[self.embodiment]["action"])

    @property
    def indices(self) -> tuple[int, ...]:
        """Policy-slot indices holding the raw action dimensions."""
        return self.action_slots

    def action(self, action: PolicyAction) -> PolicyAction:
        """Gather the embodiment's action dimensions back out of the policy layout."""
        if action.shape[-1] != self.policy_action_dim:
            raise ValueError(
                f"G0.5 policy action has {action.shape[-1]} dimensions, expected {self.policy_action_dim}."
            )
        return action[..., list(self.indices)]

    def transform_features(
        self, features: dict[PipelineFeatureType, dict[str, PolicyFeature]]
    ) -> dict[PipelineFeatureType, dict[str, PolicyFeature]]:
        """Narrow the action feature back to the embodiment's width."""
        result = _copy_feature_tree(features)
        actions = result.setdefault(PipelineFeatureType.ACTION, {})
        actions[ACTION] = PolicyFeature(type=FeatureType.ACTION, shape=(len(self.indices),))
        return result

    def get_config(self) -> dict[str, Any]:
        """Return this step's serializable configuration."""
        return {
            "embodiment": self.embodiment,
            "policy_action_dim": self.policy_action_dim,
            "action_slots": list(self.action_slots),
        }


@dataclass
@ProcessorStepRegistry.register(name="g05_libero_gripper")
class G05LiberoGripperStep(PolicyActionProcessorStep):
    """Convert the released checkpoint's gripper value to LIBERO's binary command."""

    def action(self, action: PolicyAction) -> PolicyAction:
        """Rewrite the trailing gripper value as LIBERO's binary open/close command."""
        if action.shape[-1] != 7:
            raise ValueError(f"G0.5 LIBERO action must have 7 dimensions, got {action.shape[-1]}.")
        value = action[..., -1]
        in_unit_interval = (value >= 0.0) & (value <= 1.0)
        open_gripper = torch.where(in_unit_interval, value > 0.5, value > 0.0)
        action = action.clone()
        action[..., -1] = torch.where(
            open_gripper,
            value.new_tensor(-1.0),
            value.new_tensor(1.0),
        )
        return action

    def transform_features(
        self, features: dict[PipelineFeatureType, dict[str, PolicyFeature]]
    ) -> dict[PipelineFeatureType, dict[str, PolicyFeature]]:
        """Pass the feature contract through unchanged."""
        return features

    def get_config(self) -> dict[str, Any]:
        """Return this step's serializable configuration."""
        return {}


@dataclass
@ProcessorStepRegistry.register(name="g05_action_history_crop")
class G05ActionHistoryCropStep(PolicyActionProcessorStep):
    """Remove the author model's observation-alignment prefix from action chunks."""

    num_obs_steps: int = 1

    def action(self, action: PolicyAction) -> PolicyAction:
        """Drop the leading steps that align the chunk with the observation history."""
        if self.num_obs_steps <= 1:
            return action
        start = self.num_obs_steps - 1
        if action.ndim < 2 or action.shape[-2] <= start:
            raise ValueError(
                "G0.5 action history crop requires a full action chunk with at least "
                f"{self.num_obs_steps} steps, got {tuple(action.shape)}."
            )
        return action[..., start:, :]

    def transform_features(
        self, features: dict[PipelineFeatureType, dict[str, PolicyFeature]]
    ) -> dict[PipelineFeatureType, dict[str, PolicyFeature]]:
        """Pass the feature contract through unchanged."""
        return features

    def get_config(self) -> dict[str, Any]:
        """Return this step's serializable configuration."""
        return {"num_obs_steps": self.num_obs_steps}


def _task_values(batch: Mapping[str, Any], task: str | None, batch_size: int) -> list[str]:
    """Broadcast the task string across the batch."""
    if task is not None:
        return [task] * batch_size
    value = batch.get("task")
    if isinstance(value, str):
        return [value] * batch_size
    if isinstance(value, list | tuple) and len(value) == batch_size:
        return [str(item) for item in value]
    raise ValueError(
        "G0.5 requires the already-selected LeRobot task string; no task augmentation "
        "or model-local sampling is performed."
    )


def _batch_item(value: Any, index: int, batch_size: int) -> Any:
    """Take one sample's value out of a batched field."""
    if isinstance(value, Tensor) and value.ndim > 0 and value.shape[0] == batch_size:
        return value[index]
    if isinstance(value, list | tuple) and len(value) == batch_size:
        return value[index]
    return value


def _sample_messages(batch: Mapping[str, Any], index: int, batch_size: int) -> Any:
    """One sample's recipe-rendered conversation, or None when no recipe ran."""
    messages = batch.get(MESSAGES_RENDERED)
    if (
        isinstance(messages, list | tuple)
        and len(messages) == batch_size
        and (not messages or isinstance(messages[0], list | tuple))
    ):
        messages = messages[index]
    return [messages] if isinstance(messages, Mapping) else messages


def _rendered_task(batch: Mapping[str, Any], index: int, batch_size: int) -> str | None:
    """The task text of one sample's rendered user turn.

    The recipe's ``${task}`` rotates through the episode's ``task_aug`` rephrasings, so
    using it as the command gives the task-prompt diversity the annotations provide.
    """
    messages = _sample_messages(batch, index, batch_size)
    if not isinstance(messages, list | tuple):
        return None
    for message in reversed(messages):
        if isinstance(message, Mapping) and message.get("role") == "user":
            text = semantic_message_content_text(message.get("content"))
            if text:
                return text
    return None


def _recipe_cot_targets(
    batch: Mapping[str, Any],
    index: int,
    batch_size: int,
) -> tuple[str | None, str | None]:
    """Read the selected recipe's supervised Subtask/BBox messages."""

    target_indices = batch.get("target_message_indices")
    sample_messages = _sample_messages(batch, index, batch_size)
    if sample_messages is None or target_indices is None:
        return None, None

    sample_target_indices = target_indices
    has_batched_target_indices = (isinstance(target_indices, Tensor) and target_indices.ndim > 1) or (
        isinstance(target_indices, list | tuple)
        and len(target_indices) == batch_size
        and (not target_indices or isinstance(target_indices[0], list | tuple | Tensor))
    )
    if has_batched_target_indices:
        sample_target_indices = target_indices[index]
    if isinstance(sample_target_indices, Tensor):
        sample_target_indices = sample_target_indices.detach().cpu().tolist()
    if not isinstance(sample_messages, list | tuple) or not isinstance(sample_target_indices, list | tuple):
        return None, None

    subtask: str | None = None
    bbox_json: str | None = None
    for target_index in sample_target_indices:
        message = sample_messages[int(target_index)]
        content = message.get("content") if isinstance(message, Mapping) else None
        if not isinstance(content, str):
            continue
        if content.startswith("Subtask:"):
            value = content.removeprefix("Subtask:").strip()
            if value:
                subtask = value
        elif content.startswith("BBoxJSON:"):
            value = content.removeprefix("BBoxJSON:").strip()
            if value:
                bbox_json = value
    return subtask, bbox_json


def format_g05_bbox_target(bbox_json: str | None) -> str | None:
    """Convert LeRobot grounded-VQA JSON into G0.5's location-token format.

    Coordinates are [0, 1] fractions of the image, the LeRobot annotation convention and
    the frame the checkpoint was trained in; each becomes one of 1024 location tokens, in
    (y1, x1, y2, x2) order.
    """

    if not bbox_json:
        return None
    try:
        payload = json.loads(bbox_json)
        if isinstance(payload, str):
            payload = json.loads(payload)
    except (json.JSONDecodeError, TypeError):
        return None
    if not isinstance(payload, Mapping):
        return None
    if isinstance(payload.get("answer"), Mapping):
        payload = payload["answer"]

    boxes: list[tuple[str, list[float]]] = []
    detections = payload.get("detections")
    if isinstance(detections, list):
        for detection in detections:
            if not isinstance(detection, Mapping):
                continue
            coords = detection.get("bbox")
            bbox_format = detection.get("bbox_format", "xyxy")
            if (
                not isinstance(coords, list | tuple)
                or len(coords) != 4
                or bbox_format not in {"xyxy", "xywh"}
            ):
                continue
            x1, y1, a, b = (float(value) for value in coords)
            corners = [x1, y1, x1 + a, y1 + b] if bbox_format == "xywh" else [x1, y1, a, b]
            boxes.append((str(detection.get("label") or "object"), corners))
    else:
        for label, coords in payload.items():
            if isinstance(coords, list | tuple) and len(coords) == 4:
                boxes.append((str(label), [float(value) for value in coords]))
    if not boxes:
        return None
    if any(not 0.0 <= value <= 1.0 for _, coords in boxes for value in coords):
        raise ValueError(
            "G0.5 bbox targets need [0, 1] image-fraction coordinates (the lerobot-annotate "
            f"convention), got {bbox_json!r}. Convert pixel boxes by dividing by the frame size."
        )

    def location_token(value: float) -> str:
        """Render a coordinate as a location token."""
        location = max(0, min(1023, round(value * 1024)))
        return f"<loc{location:04d}>"

    formatted = []
    for label, (x1, y1, x2, y2) in boxes:
        locations = "".join(location_token(value) for value in (y1, x1, y2, x2))
        formatted.append(f"{label} {locations}")
    return "BBox: " + "; ".join(formatted)


def _apply_recipe_cot(
    config: Any,
    flow_only: bool,
    sample: dict[str, Any],
    batch: Mapping[str, Any],
    index: int,
    batch_size: int,
) -> bool:
    """Populate one author sample from recipe-rendered CoT targets."""

    subtask, bbox_json = _recipe_cot_targets(batch, index, batch_size)
    bbox = format_g05_bbox_target(bbox_json)

    fields = tuple(field for field, value in (("bbox", bbox), ("subtask", subtask)) if value)
    if not fields:
        return False
    sample["template"] = make_g05_cot_prompt_template(
        config.num_prompt_images,
        fields=fields,
        flow_only=flow_only,
    )
    if bbox is not None:
        sample["bbox"] = bbox
    if subtask is not None:
        sample["atomic_task"] = f"Subtask: {subtask}"
    sample["prompt"] = G05_COT_PROMPTS[fields]
    return True


def prepare_g05_policy_batch(
    config: Any,
    batch: Mapping[str, Any],
    *,
    task: str | None = None,
    predict_cot: bool | None = None,
) -> dict[str, Any]:
    """Build G0.5's author-format sample batch from a processed LeRobot batch.

    ``config`` is a `G05Config`, or the namespace of its fields that `G05TokenizerStep` holds.
    """
    run_predict_cot = config.predict_cot if predict_cot is None else predict_cot

    state = batch.get(OBS_STATE)
    if not isinstance(state, Tensor):
        raise ValueError(f"G0.5 requires tensor {OBS_STATE!r}.")
    if state.ndim == 1:
        state = state.unsqueeze(0)
    batch_size = state.shape[0]
    tasks = _task_values(batch, task, batch_size)

    pixel_values: dict[str, Tensor] = {}
    for key in config.camera_order:
        image = batch.get(key)
        if not isinstance(image, Tensor):
            raise ValueError(f"G0.5 requires camera {key!r}; camera order is checkpoint state.")
        if image.ndim == 4:
            image = image.unsqueeze(1)
        pixel_values[key] = image
    image_count = sum(image.shape[1] for image in pixel_values.values())
    if image_count != config.num_input_images:
        raise ValueError(
            f"G0.5 received {image_count} camera/history frames, but the checkpoint "
            f"template requires {config.num_input_images}."
        )

    samples = []
    flow_only = "<action_action" not in config.prompt_template
    system1_template = make_g05_prompt_template(
        config.num_prompt_images, predict_cot=False, flow_only=flow_only
    )
    inference_template = config.prompt_template if run_predict_cot else system1_template
    for index, raw_task in enumerate(tasks):
        if task is None:
            raw_task = _rendered_task(batch, index, batch_size) or raw_task
        proprio = state[index]
        if proprio.ndim == 1:
            proprio = proprio.unsqueeze(0)
        sample = {
            "template": inference_template,
            # This is the author InputPreprocessor command slot. Keep it byte-for-byte
            # unchanged; checkpoint-specific chat formatting occurs downstream.
            "command": raw_task,
            "embodiment": config.embodiment,
            "proprio": {"value": proprio},
        }
        frequency = config.processor_metadata.get("frequency")
        if frequency is not None:
            sample["frequency"] = frequency
        if run_predict_cot:
            rendered_recipe = MESSAGES_RENDERED in batch
            applied_recipe_cot = rendered_recipe and _apply_recipe_cot(
                config, flow_only, sample, batch, index, batch_size
            )
            if not applied_recipe_cot:
                # During mixed-recipe training an applicable no-CoT branch is a
                # genuine target format. At inference, where actions are absent,
                # retain the checkpoint's configured System 2 prompt.
                if rendered_recipe and isinstance(batch.get(ACTION), Tensor):
                    sample["template"] = system1_template
                else:
                    sample["prompt"] = G05_COT_PROMPTS[tuple(config.runtime_cot_fields)]
                    atomic_task = batch.get("atomic_task")
                    if atomic_task is not None:
                        atomic_task = str(_batch_item(atomic_task, index, batch_size))
                        sample["atomic_task"] = (
                            atomic_task if atomic_task.startswith("Subtask:") else f"Subtask: {atomic_task}"
                        )
        for image_index in range(config.num_prompt_images):
            camera = config.camera_order[image_index % len(config.camera_order)]
            sample[f"image{image_index}"] = config.camera_sizes[camera]
        action = batch.get(ACTION)
        if "<action_action" in config.prompt_template:
            if not isinstance(action, Tensor):
                action = state.new_zeros(batch_size, config.chunk_size, config.policy_action_dim)
            action_dim_is_pad = batch.get("action_dim_is_pad")
            if action_dim_is_pad is None:
                action_dim_is_pad = torch.zeros(
                    batch_size,
                    config.policy_action_dim,
                    dtype=torch.bool,
                    device=action.device,
                )
            elif action_dim_is_pad.ndim == 1:
                action_dim_is_pad = action_dim_is_pad.unsqueeze(0).expand(batch_size, -1)
            action_payload = {
                "value": action[index],
                "action_dim_is_pad": action_dim_is_pad[index],
            }
            action_op_mask = batch.get("action_op_mask")
            if isinstance(action_op_mask, Tensor):
                action_payload["action_op_mask"] = (
                    action_op_mask[index] if action_op_mask.ndim > 1 else action_op_mask
                )
            else:
                action_payload["action_op_mask"] = ~action_dim_is_pad[index]
            sample["action"] = action_payload
        samples.append(sample)
    prepared = dict(batch)
    prepared["samples"] = samples
    prepared["pixel_values"] = pixel_values
    prepared[G05_RUNTIME_PREDICT_COT] = run_predict_cot
    return prepared


def _tokenizer_policy_config(config: G05Config) -> dict[str, Any]:
    """Collect the policy fields `G05TokenizerStep` reads at inference time.

    This is derived from the live config on every load rather than serialized into
    the step, so the pipeline cannot drift from the checkpoint it is paired with.
    """
    return {
        "author_model_config": config.author_model_config,
        "embodiment": config.embodiment,
        "predict_cot": config.predict_cot,
        "runtime_system": config.runtime_system,
        "prompt_template": config.prompt_template,
        "num_prompt_images": config.num_prompt_images,
        "num_input_images": config.num_input_images,
        "camera_order": config.camera_order,
        "camera_sizes": config.camera_sizes,
        "policy_state_dim": config.policy_state_dim,
        "policy_action_dim": config.policy_action_dim,
        "chunk_size": config.chunk_size,
        "processor_metadata": config.processor_metadata,
        "cot_bbox_camera": config.cot_bbox_camera,
        "runtime_cot_fields": config.runtime_cot_fields,
        "proprio_dropout_p": config.proprio_dropout_p,
    }


def _training_recipe(config: G05Config) -> TrainingRecipe | None:
    """The config's serialized recipe as the `TrainingRecipe` the render steps take."""
    if config.recipe is None:
        return None
    # Imported here: recipes need the dataset extras, the policy does not.
    from lerobot.datasets.recipe import TrainingRecipe

    return TrainingRecipe.from_dict(config.recipe)


def _slot_mapping(config: G05Config) -> dict[str, tuple[int, ...]]:
    """The config's state/action slots, which a policy without a named embodiment gets from its dataset."""
    mapping = config.slot_mapping
    if mapping is None:
        raise ValueError(
            f"G0.5 embodiment {config.embodiment!r} has no named slot table; set state_slots and "
            "action_slots, or build the policy from a dataset whose features carry joint names."
        )
    return mapping


def _project_stats(
    config: G05Config,
    dataset_stats: dict[str, dict[str, torch.Tensor]] | None,
) -> dict[str, dict[str, torch.Tensor]] | None:
    """Scatter raw per-joint dataset stats into the wider policy embodiment layout."""
    if not dataset_stats:
        return dataset_stats
    result: dict[str, dict[str, torch.Tensor]] = {}
    mapping = _slot_mapping(config)
    widths = {OBS_STATE: config.policy_state_dim, ACTION: config.policy_action_dim}
    index_maps = {OBS_STATE: mapping["state"], ACTION: mapping["action"]}
    for feature_name, stats in dataset_stats.items():
        if feature_name not in widths:
            result[feature_name] = stats
            continue
        projected_stats: dict[str, torch.Tensor] = {}
        for stat_name, raw_value in stats.items():
            value = torch.as_tensor(raw_value)
            if stat_name == "count":
                # LeRobot dataset stats carry a scalar sample count that is not
                # a per-dimension statistic; pass it through unprojected.
                projected_stats[stat_name] = value
                continue
            if value.shape[-1] != len(index_maps[feature_name]):
                raise ValueError(
                    f"{feature_name}.{stat_name} has width {value.shape[-1]}, "
                    f"expected {len(index_maps[feature_name])} for {config.embodiment}."
                )
            fill = {
                "std": 1.0,
                "q01": -1.0,
                "q99": 1.0,
                "min": -1.0,
                "max": 1.0,
            }.get(stat_name, 0.0)
            projected = value.new_full((*value.shape[:-1], widths[feature_name]), fill)
            projected[..., list(index_maps[feature_name])] = value
            projected_stats[stat_name] = projected
        result[feature_name] = projected_stats
    return result


def fix_g05_train_overrides(
    config: G05Config,
    preprocessor_overrides: dict[str, Any] | None,
    postprocessor_overrides: dict[str, Any] | None,
) -> tuple[dict[str, Any] | None, dict[str, Any] | None]:
    """Adapt ``lerobot-train``'s generic normalizer overrides to G0.5's pipeline.

    ``lerobot-train`` assumes a ``normalizer_processor``/``unnormalizer_processor`` step pair
    that normalizes raw dataset-space stats. G0.5's normalizer instead runs after
    ``G05EmbodimentProjectionStep`` (policy-space, padded dims), and its unnormalizer is renamed
    to ``g05_stepwise_unnormalizer`` when per-timestep stats are enabled. Left alone, the override
    either targets a step name that doesn't exist (unnormalizer) or replaces the projected stats
    with raw ones (normalizer). The same goes for the ``relative_actions_processor`` override a
    relative-action run adds: G0.5's relative step is registered as ``g05_relative_joint_actions``.
    """
    preprocessor_overrides = dict(preprocessor_overrides or {})
    relative_override = preprocessor_overrides.pop("relative_actions_processor", None)
    if relative_override is not None:
        preprocessor_overrides["g05_relative_joint_actions"] = relative_override
    normalizer_override = preprocessor_overrides.get("normalizer_processor")
    if normalizer_override is not None:
        normalizer_override = dict(normalizer_override)
        if normalizer_override.get("stats") is not None:
            normalizer_override["stats"] = _project_stats(config, normalizer_override["stats"])
        preprocessor_overrides["normalizer_processor"] = normalizer_override

    postprocessor_overrides = dict(postprocessor_overrides or {})
    unnormalizer_override = postprocessor_overrides.pop("unnormalizer_processor", None)
    if unnormalizer_override is not None:
        unnormalizer_override = dict(unnormalizer_override)
        if unnormalizer_override.get("stats") is not None:
            unnormalizer_override["stats"] = _project_stats(config, unnormalizer_override["stats"])
        registry_name = (
            "g05_stepwise_unnormalizer" if config.use_stepwise_action_norm else "unnormalizer_processor"
        )
        postprocessor_overrides[registry_name] = unnormalizer_override

    return preprocessor_overrides, postprocessor_overrides


def reconcile_g05_processors(
    config: G05Config,
    preprocessor: PolicyProcessorPipeline,
    postprocessor: PolicyProcessorPipeline,
) -> tuple[PolicyProcessorPipeline, PolicyProcessorPipeline]:
    """Hand the loaded steps the fields the live config owns rather than the saved pipeline.

    The training recipe is one of them: a checkpoint saved without recipe training
    stores its training renderer with no recipe, and a fine-tune that turns the
    recipe on (or off) switches it here instead of rebuilding the pipeline.
    """
    steps = list(preprocessor.steps)
    for index, step in enumerate(steps):
        if isinstance(step, RenderTrainingMessagesStep):
            recipe = _training_recipe(config) if config.use_language_recipe else None
            steps[index] = RenderTrainingMessagesStep(recipe, dataset_ctx=step.dataset_ctx)
        if isinstance(step, G05TokenizerStep):
            step.policy_config = _tokenizer_policy_config(config)
    preprocessor.steps = steps
    return preprocessor, postprocessor


def make_g05_pre_post_processors_from_pretrained(
    config: G05Config,
    pretrained_path: str,
    *,
    revision: str | None = None,
    dataset_stats: dict[str, dict[str, torch.Tensor]] | None = None,
    dataset_meta: Any | None = None,
    preprocessor_overrides: dict[str, Any] | None = None,
    postprocessor_overrides: dict[str, Any] | None = None,
    preprocessor_config_filename: str = f"{POLICY_PREPROCESSOR_DEFAULT_NAME}.json",
    postprocessor_config_filename: str = f"{POLICY_POSTPROCESSOR_DEFAULT_NAME}.json",
) -> tuple[
    PolicyProcessorPipeline[dict[str, Any], dict[str, Any]],
    PolicyProcessorPipeline[PolicyAction, PolicyAction],
]:
    """Load the serialized G0.5 pipelines and reconcile them with the live config.

    Dataset stats reach the pipelines through the normalizer overrides, which
    `fix_g05_train_overrides` projects into the checkpoint's policy space.
    """
    del dataset_stats, dataset_meta

    prepared_preprocessor_overrides, prepared_postprocessor_overrides = fix_g05_train_overrides(
        config, preprocessor_overrides, postprocessor_overrides
    )
    preprocessor, postprocessor = load_pretrained_policy_processors(
        pretrained_path,
        revision=revision,
        preprocessor_overrides=prepared_preprocessor_overrides,
        postprocessor_overrides=prepared_postprocessor_overrides,
        preprocessor_config_filename=preprocessor_config_filename,
        postprocessor_config_filename=postprocessor_config_filename,
    )
    return reconcile_g05_processors(config, preprocessor, postprocessor)


def _sidecar_root(config: G05Config) -> Path:
    """Return the local checkpoint directory holding the tokenizer sidecars.

    `lerobot-train` rebuilds these pipelines from the config with `pretrained_path`
    still set to what `--policy.path` named, which may be a Hub repo id.
    """
    if config.pretrained_path is None:
        return Path()
    root = Path(str(config.pretrained_path))
    if root.is_dir():
        return root
    return Path(
        snapshot_download(
            repo_id=str(config.pretrained_path),
            revision=config.pretrained_revision,
            allow_patterns=["hf_processor/**", "action_tokenizer.safetensors"],
        )
    )


def make_g05_pre_post_processors(
    config: G05Config,
    dataset_stats: dict[str, dict[str, torch.Tensor]] | None = None,
) -> tuple[
    PolicyProcessorPipeline[dict[str, Any], dict[str, Any]],
    PolicyProcessorPipeline[PolicyAction, PolicyAction],
]:
    """Build serializable G0.5 pipelines from checkpoint-authoritative metadata."""

    if dataset_stats:
        for key, feature_type in ((OBS_STATE, "STATE"), (ACTION, "ACTION")):
            quantiles = config.normalization_mapping.get(feature_type) == NormalizationMode.QUANTILES
            if quantiles and key in dataset_stats and not {"q01", "q99"} <= set(dataset_stats[key]):
                raise ValueError(f"{key} requires real q01/q99 statistics; min/max must not be substituted.")
    policy_features = dict(config.input_features or {})
    policy_features.update(config.output_features or {})
    policy_features[OBS_STATE] = PolicyFeature(type=FeatureType.STATE, shape=(config.policy_state_dim,))
    policy_features[ACTION] = PolicyFeature(type=FeatureType.ACTION, shape=(config.policy_action_dim,))
    projected_stats = _project_stats(config, dataset_stats)

    relative_step = G05RelativeJointActionsStep(
        enabled=config.use_relative_actions,
        exclude_joints=list(config.relative_exclude_joints),
        action_names=list(config.action_feature_names) or None,
        num_obs_steps=config.n_obs_steps,
    )
    recipe = _training_recipe(config)
    steps: list[ProcessorStep] = [
        # The runtime renderer always carries the checkpoint recipe so a saved
        # pipeline can answer `next_subtask`; the training renderer no-ops on a
        # `None` recipe, which is how recipe training stays opt-in.
        RenderRuntimeMessagesStep(recipe),
        RenderTrainingMessagesStep(recipe if config.use_language_recipe else None),
        RenameObservationsProcessorStep(rename_map={}),
        AddBatchDimensionProcessorStep(),
    ]
    steps.append(
        G05ImageTransformStep(
            camera_order=config.camera_keys,
            camera_sizes=config.camera_sizes,
            mean=config.image_mean,
            std=config.image_std,
            optional_camera_keys=config.optional_camera_keys,
        )
    )
    action_filter = config.processor_metadata.get("action_filter") or {}
    # The filter describes R1Lite's action parts; another embodiment fine-tuned from
    # the same checkpoint keeps the metadata but not the layout it applies to.
    if config.embodiment == "galaxea_r1lite" and str(action_filter.get("_target_", "")).endswith(
        "R1LiteJointActionFilter"
    ):
        action_parts = tuple(
            (str(item["key"]), int(item["shape"]))
            for item in (config.processor_metadata.get("shape_meta") or {}).get("action", [])
        )
        steps.append(
            G05ActionOperationMaskStep(
                action_parts=action_parts,
                joint_threshold=action_filter.get("joint_threshold"),
                gripper_threshold=action_filter.get("gripper_threshold"),
                velocity_threshold=action_filter.get("velocity_threshold"),
                eef_threshold=action_filter.get("eef_threshold", 1e-3),
                dim_thresholds=action_filter.get("dim_thresholds") or {},
            )
        )
    steps.extend(
        [
            *_joint_frame_input_steps(config),
            relative_step,
            G05EmbodimentProjectionStep(
                embodiment=config.embodiment,
                policy_state_dim=config.policy_state_dim,
                policy_action_dim=config.policy_action_dim,
                camera_order=config.camera_keys,
                state_slots=_slot_mapping(config)["state"],
                action_slots=_slot_mapping(config)["action"],
            ),
        ]
    )
    steps.append(
        NormalizerProcessorStep(
            features=policy_features,
            norm_map=config.normalization_mapping,
            stats=projected_stats,
        )
    )
    if config.normalization_clip is not None:
        steps.append(
            G05NormalizationClampStep(
                minimum=config.normalization_clip[0],
                maximum=config.normalization_clip[1],
            )
        )
    # `PreTrainedConfig.__post_init__` resolves the device; the field is only typed optional.
    steps.append(DeviceProcessorStep(device=config.device or "cpu"))
    checkpoint_root = _sidecar_root(config)
    steps.append(
        G05TokenizerStep(
            processor_dir=str(checkpoint_root / "hf_processor"),
            action_tokenizer_path=str(checkpoint_root / "action_tokenizer.safetensors"),
            policy_config=_tokenizer_policy_config(config),
        )
    )
    preprocessor = PolicyProcessorPipeline[dict[str, Any], dict[str, Any]](
        steps=steps,
        name=POLICY_PREPROCESSOR_DEFAULT_NAME,
        to_transition=batch_to_transition,
        to_output=transition_to_batch,
    )
    unnormalizer_cls = (
        G05StepwiseUnnormalizerStep if config.use_stepwise_action_norm else UnnormalizerProcessorStep
    )
    unnormalizer_kwargs: dict[str, Any] = {
        "features": {ACTION: policy_features[ACTION]},
        "norm_map": config.normalization_mapping,
        "stats": projected_stats,
    }
    if config.use_stepwise_action_norm:
        unnormalizer_kwargs["n_action_steps"] = config.n_action_steps
    output_steps: list[ProcessorStep] = [
        unnormalizer_cls(
            **unnormalizer_kwargs,
        )
    ]
    output_steps.append(
        G05InverseActionProjectionStep(
            embodiment=config.embodiment,
            policy_action_dim=config.policy_action_dim,
            action_slots=_slot_mapping(config)["action"],
        )
    )
    if config.libero_gripper_binarize:
        output_steps.append(G05LiberoGripperStep())
    output_steps.extend(
        [
            DeviceProcessorStep(device="cpu"),
            AbsoluteActionsProcessorStep(enabled=config.use_relative_actions, relative_step=relative_step),
            _joint_frame_output_step(config),
            G05ActionHistoryCropStep(num_obs_steps=config.n_obs_steps),
        ]
    )
    postprocessor = PolicyProcessorPipeline[PolicyAction, PolicyAction](
        steps=output_steps,
        name=POLICY_POSTPROCESSOR_DEFAULT_NAME,
        to_transition=policy_action_to_transition,
        to_output=transition_to_policy_action,
    )
    return preprocessor, postprocessor


def _joint_frame_input_steps(config: G05Config) -> list[ProcessorStep]:
    """Preprocessor half: both go ahead of the relative-action step, which
    differences deltas in the checkpoint's joint frame."""

    return [
        G05StateFrameTransformStep(joint_signs=config.joint_signs, joint_offsets=config.joint_offsets),
        G05ActionFrameTransformStep(
            joint_signs=config.joint_signs,
            joint_offsets=config.joint_offsets,
            inverse=False,
        ),
    ]


def _joint_frame_output_step(config: G05Config) -> ProcessorStep:
    """Postprocessor half: back to the arm frame once the action is absolute."""

    return G05ActionFrameTransformStep(
        joint_signs=config.joint_signs,
        joint_offsets=config.joint_offsets,
        inverse=True,
    )


@dataclass
@ProcessorStepRegistry.register(name="g05_tokenizer")
class G05TokenizerStep(ProcessorStep):
    """Build the checkpoint-native G0.5 token sequence in the input pipeline."""

    # Declared artifacts: saved into the checkpoint by `save_artifacts` and handed
    # back as resolved absolute paths by the pipeline loader, which downloads them
    # from the Hub when the pipeline is loaded from a repo id.
    processor_dir: str
    action_tokenizer_path: str
    # Not serialized: the live G05Config owns these fields and re-injects them on
    # load via `_tokenizer_policy_config`, so a pipeline restored from JSON builds
    # this step without them and is filled in by `reconcile_g05_processors`.
    policy_config: dict[str, Any] = field(default_factory=dict)
    _tokenizer: G05Tokenizer | None = field(default=None, init=False, repr=False)
    _action_codec: Any = field(default=None, init=False, repr=False)

    def get_config(self) -> dict[str, Any]:
        """Return this step's serializable configuration."""
        return {
            "processor_dir": self.processor_dir,
            "action_tokenizer_path": self.action_tokenizer_path,
        }

    def save_artifacts(self, save_directory: Path) -> dict[str, str]:
        """Copy the tokenizer bundle and ActionCodec weights into the checkpoint.

        A pipeline built from a config without a packaged checkpoint has nothing to
        copy; it declares no artifact and keeps the configured paths, so building a
        pipeline for inspection stays possible without the sidecars on disk.
        """
        artifacts: dict[str, str] = {}
        processor_dir = Path(self.processor_dir)
        target_processor = save_directory / "hf_processor"
        if processor_dir.is_dir():
            if processor_dir.resolve() != target_processor.resolve():
                shutil.copytree(processor_dir, target_processor, dirs_exist_ok=True)
            artifacts["processor_dir"] = "hf_processor"

        action_tokenizer_path = Path(self.action_tokenizer_path)
        target_tokenizer = save_directory / "action_tokenizer.safetensors"
        if action_tokenizer_path.is_file():
            if action_tokenizer_path.resolve() != target_tokenizer.resolve():
                shutil.copy2(action_tokenizer_path, target_tokenizer)
            artifacts["action_tokenizer_path"] = "action_tokenizer.safetensors"
        return artifacts

    def _get_tokenizer(self) -> G05Tokenizer:
        """Build the tokenizer on first use and cache it on the step."""
        if self._tokenizer is not None:
            return self._tokenizer
        processor_path = Path(self.processor_dir)
        model_config = dict(self.policy_config["author_model_config"])
        model_config.update(
            {
                "embodiment": self.policy_config["embodiment"],
                "predict_cot": self.policy_config["predict_cot"],
            }
        )
        self._tokenizer = G05Tokenizer(processor_path, model_config)
        return self._tokenizer

    def _get_action_codec(self, device: torch.device):
        """Build the native action codec on first use, or None when the checkpoint has none."""
        if self._action_codec is None:
            tokenizer = self._get_tokenizer()
            action_config = tokenizer.model_config.get("AT_CONFIG")
            if action_config is None or not Path(self.action_tokenizer_path).is_file():
                return None
            self._action_codec = G05NativeActionCodec.load(
                action_config,
                action_token_begin=tokenizer.action_token_begin,
                ckpt_path=self.action_tokenizer_path,
            )
        return self._action_codec.to(device)

    def __call__(self, transition: EnvTransition) -> EnvTransition:
        """Turn the transition into the checkpoint-native token sequence."""
        tokenizer = self._get_tokenizer()
        transition = transition.copy()
        observation = dict(transition.get(TransitionKey.OBSERVATION) or {})
        complementary = dict(transition.get(TransitionKey.COMPLEMENTARY_DATA) or {})
        batch: dict[str, Any] = {**observation, **complementary}
        action = transition.get(TransitionKey.ACTION)
        if action is not None:
            batch[ACTION] = action
        state = batch.get(OBS_STATE)
        if not isinstance(state, Tensor):
            raise ValueError("G0.5 requires tensor observation.state before tokenization.")

        messages = complementary.get(MESSAGES_RENDERED)
        task_override = None
        if messages is not None and action is None:
            conversation = require_single_semantic_conversation(messages, policy_name="G0.5")
            task_override = last_semantic_message_text(conversation, role="user")
        run_predict_cot = bool(messages is not None) or (
            self.policy_config["predict_cot"] and self.policy_config["runtime_system"] == "system2"
        )
        config = SimpleNamespace(**self.policy_config)
        prepared = prepare_g05_policy_batch(
            config,
            batch,
            task=task_override,
            predict_cot=run_predict_cot,
        )
        if action is None:
            sequence = tokenizer.encode_inference(prepared["samples"], device=state.device)
        else:
            sequence = tokenizer.encode_train(
                prepared["samples"],
                device=state.device,
                action_codec=self._get_action_codec(state.device),
                proprio_dropout_p=float(self.policy_config.get("proprio_dropout_p", 0.0)),
            )
        complementary.update(
            {
                "samples": prepared["samples"],
                "pixel_values": prepared["pixel_values"],
                G05_RUNTIME_PREDICT_COT: run_predict_cot,
                G05_INPUT_IDS: sequence.input_ids,
                G05_LABELS: sequence.labels,
                G05_TOKEN_TYPES: sequence.token_types,
                G05_SPLIT_INDEX: sequence.split_index,
            }
        )
        transition[TransitionKey.COMPLEMENTARY_DATA] = complementary
        return transition

    def transform_features(
        self, features: dict[PipelineFeatureType, dict[str, PolicyFeature]]
    ) -> dict[PipelineFeatureType, dict[str, PolicyFeature]]:
        """Pass the feature contract through unchanged."""
        return features
